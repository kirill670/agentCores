# src/agentCore/__init__.py
from .agentCore import agentCore
from .agentMatrix import agentMatrix

__version__ = "0.1.0"
__all__ = ["agentCore", "agentMatrix"]